
<nav id="menu">
    <a href="index.php">Liste des produits</a>
    <a href="recap.php">Voir mon panier</a>
    <!-- normalement réservé aux admins du site -->
    <a href="form.php">Administration</a>
</nav>