<nav id="menu">
    <a href="index.php">Ajouter un produit</a>
    <a href="recap.php">Liste des produits</a>
</nav>